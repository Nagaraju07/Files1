﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab11Q1
{
    class Bank
    {
        //class bank having delegates
        public delegate void BankDelegate(string message);
        public event BankDelegate BankEvent;

        public void Notify(string message)
        {
            if (BankEvent != null)
                BankEvent(message);
        }
    }

    //SMS gateway for notification
    class SMSGateway
    {
        static public void SendMessage(string message)
        {
            Console.WriteLine(message);
        }
    }

    //Credit card operations are performed by CreditCard class 
    public class CreditCard
    {

        public int CreditCardLimit;

        public CreditCard(int creditCardLimit)
        {
            CreditCardLimit = creditCardLimit;
        }

        public int GetBalance()
        {
            return CreditCardLimit;
        }

        public int GetCreditLimit()
        {
            return 10000;
        }

        public void MakePayment(int amount)
        {
            string message = "";
            if (CreditCardLimit > amount)
            {
                CreditCardLimit = CreditCardLimit - amount;
                message = "Withdrawn Amount : " + amount + "\t Remaining Credit Crad Limit : " + CreditCardLimit;
            }
            else
            {
                message = "You are trying to pay greater amount than your current Credit Limit";
            }

            Bank b = new Bank();
            b.BankEvent += SMSGateway.SendMessage;
            b.Notify(message);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {

            // The Credit limit is set to 10000 initially.

            CreditCard c = new CreditCard(10000);

            Console.WriteLine("Payment Gateway");

            Console.WriteLine("Your current Credit Card limit is 10000 Rupees.");

            Console.Write("Please enter the amount for making payment : ");

            int amount = Convert.ToInt32(Console.ReadLine());

            c.MakePayment(amount);

            int choice;

            while (true)
            {
                Console.Write("\n Do you wish to continue with another Payment press 1 else 2 :");
                choice = Convert.ToInt32(Console.ReadLine());
                if (choice == 1)
                {
                    Console.Write("Please enter the amount for making payment : ");

                    amount = Convert.ToInt32(Console.ReadLine());

                    c.MakePayment(amount);
                }
                else
                    Environment.Exit(1);
            }

           
        }
    }
}
