﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supplier
{
    class SupplierTest : Supplier
    {
        static void Main(string[] args)
        {
            Supplier s1 = new Supplier();
            s1.AcceptDetails();
            s1.DisplayDetails();
            Console.ReadKey();
        }
    }
}
