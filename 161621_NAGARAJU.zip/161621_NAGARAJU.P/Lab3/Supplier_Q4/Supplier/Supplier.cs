﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Supplier
{
    class Supplier
    {
        private int supplierID;
        private string supplierName;
        private string city;
        private string phoneNo;
        private string email;


        public void AcceptDetails()
        {
            Console.WriteLine("Enter Supplier ID: ");
            supplierID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Supplier Name: ");
            supplierName = Console.ReadLine();
            Console.WriteLine("Enter Supplier City: ");
            city = Console.ReadLine();
            Console.WriteLine("Enter Supplier Phone No.: ");
            phoneNo = Console.ReadLine();
            Console.WriteLine("Enter Supplier EmailID: ");
            email = Console.ReadLine();
        }

        public void DisplayDetails()
        {
            Console.WriteLine("Supplier ID: " + supplierID);
            Console.WriteLine("Supplier Name: " + supplierName);
            Console.WriteLine("Supplier City: " + city);
            Console.WriteLine("Supplier PhoneNo: " + phoneNo);
            Console.WriteLine("Supplier EmailID: " + email);

        }
    }
}
