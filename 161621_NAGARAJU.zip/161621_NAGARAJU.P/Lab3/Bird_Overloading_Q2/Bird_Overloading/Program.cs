﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bird
{
    public class Program

    {
        static void Main(string[] args)
        {
          
                Bird b = new Bird(“Mountain Eagle” , double.Parse("200"));
                b.fly();
                b.fly("300");

        }
    }
 }

