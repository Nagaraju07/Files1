﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExamParticipants;

namespace CorporateUniversityApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            int EmpId;
            string Name;
            Console.WriteLine("Enter EmpID : ");
            EmpId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Name : ");
            Name = Console.ReadLine();
            Console.WriteLine("Enter Marks Of Employee : ");
            double webMarks, FoundationMarks, dotNetMarks;
            Console.Write("Enter Marks Of web : ");
            webMarks = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Marks Of foundation : ");
            FoundationMarks = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Marks Of dotNet : ");
            dotNetMarks = Convert.ToDouble(Console.ReadLine());
            Participant MyParticipant = new Participant(EmpId, Name, FoundationMarks, webMarks, dotNetMarks);
            //Participant p = new Participant(EmpId, Name, FoundationMarks, webMarks, dotNetMarks);
            MyParticipant.EmpTotalMarks = 300;
            Console.WriteLine("\n {0}", MyParticipant.EmpTotalMarks);
            MyParticipant.EmpFoundationMarks = FoundationMarks;
            MyParticipant.EmpWebBAsicsMarks = webMarks;
            MyParticipant.EmpDotNetMarks = dotNetMarks;

            MyParticipant.CalculateTotalMarks();
            MyParticipant.CalculatePercentage();
            Console.WriteLine("\npercentage is : ");
            Console.Write(MyParticipant.ReturnPercentage());
            Console.ReadKey();
        }
    }
}
