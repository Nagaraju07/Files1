﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamParticipants
{
    class Participant
    {
        private int EmpId;
        private string Name;
        private static string CompanyName;
        private static double TotalMarks = 300;
        private double FoundationMarks, WebBasicMarks, DotNetMarks, ObtainedMarks, Percentage;
        public int EmpID { get; set; }
        public string EmpName { get; set; }
        public string EmpCompanyName { get; set; }
        public double EmpFoundationMarks
        {
            get
            {
                return FoundationMarks;
            }
            set
            {
                if (value >= 0 && value <= 100)
                {

                    FoundationMarks = value;
                }
                else
                    FoundationMarks = 0;
            }
        }
        public double EmpWebBAsicsMarks
        {
            get
            { return WebBasicMarks; }
            set
            {
                if (value >= 0 && value <= 100)
                {

                    WebBasicMarks = value;
                }
                else
                    WebBasicMarks = 0;
            }
        }
        public double EmpDotNetMarks
        {
            get
            {
                return DotNetMarks;
            }
            set
            {
                if (value >= 0 && value <= 100)
                {

                    DotNetMarks = value;
                }
                else
                    DotNetMarks = 0;
            }
        }
        public double EmpTotalMarks { get; set; }
        public double EmpObtainedMarks { get; set; }
        public double EmpPercentage { get; set; }

        public Participant()
        {
            Console.WriteLine("default cnstrctr invoked");

            TotalMarks = 300;
        }
        static Participant()
        {
            Console.WriteLine("stat cnstrctr invoked");

            CompanyName = "Corporate University";
            TotalMarks = 300;

        }
        public Participant(int EmpId, string Name, double FoundationMarks, double WebBasicMarks, double DotNetMarks)
        {
            this.EmpId = EmpId;
            this.Name = Name;
            this.FoundationMarks = FoundationMarks;
            this.WebBasicMarks = WebBasicMarks;
            this.DotNetMarks = DotNetMarks;


        }
        public void CalculateTotalMarks()
        {
            ObtainedMarks = FoundationMarks + WebBasicMarks + DotNetMarks;
        }
        public void CalculatePercentage()
        {
            Console.WriteLine("\n total marks in %ge func {0}", TotalMarks);
            Percentage = (ObtainedMarks / TotalMarks) * 100;
        }
        public double ReturnPercentage()
        {

            return Percentage;
        }
    }
}
