﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EmployeeDetails;

namespace Employees
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee[] c = new Employee[2];
            Console.WriteLine("Enter the Employee Details");
            for (int i = 0; i < c.GetLength(0); i++)
            {
                c[i] = new Employee();
                Console.WriteLine("Enter the..." + (i + 1) + "... Employee Details");

                Console.WriteLine("enter emp ID:");
                c[i].EmpID = Convert.ToInt32(Console.ReadLine());


                Console.WriteLine("enter emp Name:");
                c[i].EmpName = Console.ReadLine();

                Console.WriteLine("enter emp Address:");
                c[i].EmpAddress = Console.ReadLine();

                Console.WriteLine("enter emp city:");
                c[i].EmpCity = Console.ReadLine();

                Console.WriteLine("enter emp Department:");
                c[i].EmpDepartment = Console.ReadLine();

                Console.WriteLine("enter emp Salary:");
                c[i].EmpSal = Convert.ToDouble(Console.ReadLine());

            }

                Console.WriteLine("**************Didplay Employee Name and Salary*****************************");
                for (int i = 0; i < c.Length; i++)
                {
                Console.WriteLine(c[i].EmpName);
                    Console.WriteLine(c[i].EmpSal);
                }
            
               
                Console.ReadKey();

            }
        }
    }

