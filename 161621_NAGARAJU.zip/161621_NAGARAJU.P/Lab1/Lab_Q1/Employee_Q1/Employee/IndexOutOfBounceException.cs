﻿using System;
using System.Runtime.Serialization;

namespace Employees
{
    [Serializable]
    internal class IndexOutOfBounceException : Exception
    {
        public IndexOutOfBounceException()
        {
        }

        public IndexOutOfBounceException(string message) : base(message)
        {
        }

        public IndexOutOfBounceException(string message, Exception innerException) : base(message, innerException)
        {
        }

        protected IndexOutOfBounceException(SerializationInfo info, StreamingContext context) : base(info, context)
        {
        }
    }
}