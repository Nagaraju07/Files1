﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetails
{
    public class Employee
    {
        public int EmpID
        {  private get; set ; }
        

        public string EmpName
        {  get; set; }
        
       
        public string EmpAddress
        { private get;  set;}


        public string EmpCity
        { private get; set; }

      
        public string EmpDepartment
        { private get; set; }

        public double EmpSal
        {  get; set; }

    }
}
