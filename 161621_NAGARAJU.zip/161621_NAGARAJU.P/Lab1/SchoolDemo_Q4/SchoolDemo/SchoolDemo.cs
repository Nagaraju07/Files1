﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace St.Joseph
{
    public class SchoolDemo
    {
        private int rollNumber;
        private string studentName;
        private byte age;
        private char gender;
        private DateTime dateOfBirth;
        private string address;
        private float percentage;

        private SchoolDemo()
        {
            rollNumber = 101;
            studentName = "Joseph";
            age = 13;
            dateOfBirth = DateTime.Parse("03/03/1997");
            gender = 'M';
            address = "Arihant Frangipani,C401";
            percentage = 99.99f;
        }

        static void Main(string[] args)
        {
            SchoolDemo sc = new SchoolDemo();
            Console.WriteLine("Roll Number : {0}", sc.rollNumber);
            Console.WriteLine("Name: {0}", sc.studentName);
            Console.WriteLine("Age : {0}", sc.age);
            Console.WriteLine("Gender: {0}", sc.gender);
            Console.WriteLine("Date of Birth: {0}", sc.dateOfBirth);
            Console.WriteLine("Address:{0} ", sc.address);
            Console.WriteLine("Percentage:{0} ", sc.percentage);
            Console.ReadKey();

        }
    }
    
}
