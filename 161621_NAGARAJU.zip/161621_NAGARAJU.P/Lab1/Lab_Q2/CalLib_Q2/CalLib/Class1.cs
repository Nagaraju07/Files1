﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CalLib
{
    public class Calculator
    {
        public  int Add(int n1, int n2)
        {
            return n1 + n2;
        }
        public int Sub(int n1, int n2)
        {
            return n1 - n2;
        }
        public  int Mul(int n1, int n2)
        {
            return n1 * n2;
        }
        public int Div(int n1, int n2)
        {
            return n1 / n2;
        }
        public int Mod(int n1, int n2)
        {
            return n1 % n2;
        }

        public double DAdd(double n1, double n2)
        {
            return n1 + n2;
        }
        public double DSub(double n1, double n2)
        {
            return n1 - n2;
        }
        public double DMul(double n1, double n2)
        {
            return n1 * n2;
        }
        public double DDiv(double n1, double n2)
        {
            return n1 / n2;
        }
        public double DMod(double n1, double n2)
        {
            return n1 % n2;
        }


    }
}
