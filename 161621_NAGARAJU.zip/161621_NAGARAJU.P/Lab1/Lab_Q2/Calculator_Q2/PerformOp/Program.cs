﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CalLib;

namespace PerformOp
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("choose the requered Type: 1.Int type 2.Double type." );
            int i=Convert.ToInt32(Console.ReadLine());
           switch(i)
            {
                case 1:
                Calculator c = new Calculator();
                    int sum=c.Add(5,4);
                    int substraction=c.Sub(5, 4);
                    int multiplication=c.Mul(5, 4);
                    int division=c.Div(5, 4);
                    int modulus=c.Mod(5, 4);
                    Console.WriteLine("Addition of given numbers is:" + sum);
                    Console.WriteLine("substraction of given numbers is:" + substraction);
                    Console.WriteLine("multiplication of given numbers is:" + multiplication);
                    Console.WriteLine("division of given numbers is:" + division);
                    Console.WriteLine("modulus of given numbers is:" + modulus);
                    break;
                case 2:
                Calculator c1 = new Calculator();
                    double sum1 = c1.DAdd(5, 4);
                    double substraction1 = c1.DSub(5, 4);
                    double multiplication1 = c1.DMul(5, 4);
                    double division1 = c1.DDiv(50, 45);
                    double modulus1 = c1.DMod(55, 45);
                    Console.WriteLine("Addition of given numbers is:" + sum1);
                    Console.WriteLine("substraction of given numbers is:" + substraction1);
                    Console.WriteLine("multiplication of given numbers is:" + multiplication1);
                    Console.WriteLine("division of given numbers is:" + division1);
                    Console.WriteLine("modulus of given numbers is:" + modulus1);
                    break;
                default:
                    Console.WriteLine("Invalid");
                    break;

                }
            Console.ReadKey();
        }
    }
}
