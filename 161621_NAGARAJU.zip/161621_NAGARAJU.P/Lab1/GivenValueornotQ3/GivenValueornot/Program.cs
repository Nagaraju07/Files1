﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GivenValueornot
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("enter a number in between 1 to 5");
            int n=Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("*****************************");
            switch (n)
            {
                case 1:
                    Console.WriteLine("you are entered  1 number");
                    break;
                case 2:
                    Console.WriteLine("you are entered  2 number");
                    break;
                case 3:
                    Console.WriteLine("you are entered 3 number");
                    break;
                case 4:
                    Console.WriteLine("you are entered 4 number");
                    break;
                case 5:
                    Console.WriteLine("you are entered 5 number");
                    break;
                default:
                    Console.WriteLine("you are entered invalid number");
                    break;
            }
                    Console.ReadKey();
            
        }
    }
}
