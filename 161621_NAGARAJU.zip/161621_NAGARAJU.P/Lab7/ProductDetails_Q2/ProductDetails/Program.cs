﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ProductDetails
{
    class Program
    {


        public static void PrintMenu()
        {
            Console.WriteLine("*************************************");
            Console.WriteLine("1. Add New Product");
            Console.WriteLine("2. Delete a Product");
            Console.WriteLine("3. Search a Product");
            Console.WriteLine("4. Sort the Product");
            Console.WriteLine("5. Exit");
            Console.WriteLine("*************************************");
            Console.Write("Enter your option : ");

        }

        static void Main(string[] args)
        {
            int Operation;
            ArrayList ProductsList = new ArrayList();

            do
            {

                Console.Write("Enter Your Choice");
                Program.PrintMenu();
                Operation = Convert.ToInt32(Console.ReadLine());
                switch (Operation)
                {
                    case 1:
                        productDetails.AddProduct(ref ProductsList);
                        break;

                    case 2:
                        productDetails.DeleteProduct(ref ProductsList);
                        break;

                    case 3:
                        productDetails.SearchProduct(ref ProductsList);
                        break;
                    case 4:
                        productDetails.SortProduct(ref ProductsList);
                        break;
                    case 5:
                        productDetails.Display(ref ProductsList);
                        break;
                    case 6:
                        Environment.Exit(0);
                        break;
                    default:
                        Console.WriteLine("Please Enter A Valid Choice ");
                        break;
                }
            }
            while (Operation != 6);

            Console.ReadKey();

        }
    }
}
