﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1D_CityName
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] arr = new string[3];
            int i;
            for (i = 0; i < arr.Length; i++)
            {
                Console.WriteLine("\nEnter city name:");
                arr[i] = Console.ReadLine();
            }

            foreach (string str in arr)
            {
                Console.WriteLine("\n{0}", str);
            }
            Console.ReadKey();
        }
    }
}
