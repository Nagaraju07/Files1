﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Products
{
    class Program
    {
        static void Main(string[] args)
        {
            int productID;
            string productName;
            double productPrice, amountPayable, productQuantity;

            Console.WriteLine("Enter The Details Of Product : ");
            Console.Write("Enter Product ID: ");
            productID = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Product Name: ");
            productName = Console.ReadLine();
            Console.Write("Enter Price : ");
            productPrice = Convert.ToDouble(Console.ReadLine());
            Console.Write("Enter Quantity : ");
            productQuantity = Convert.ToInt32(Console.ReadLine());
            amountPayable = productPrice * productQuantity;
            ProductDemo myProduct = new ProductDemo(productID, productQuantity, productName, productPrice, amountPayable);
            myProduct.productBoxing();
            myProduct.productUnboxing();
            myProduct.Display();
            Console.ReadKey();
        }
    }
}
