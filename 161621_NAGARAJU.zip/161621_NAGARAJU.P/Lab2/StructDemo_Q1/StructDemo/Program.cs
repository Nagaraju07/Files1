﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructDemo
{
    class Program
    {
      static void Main(string[] args)
        {
                int num1, ch;
                string con;
                do
                {
                    Console.WriteLine("\nEnter Number: ");
                    num1 = Convert.ToInt32(Console.ReadLine());
                    Number n = new Number(num1);

                    Console.WriteLine("\nSelect Option: \n1.Square \n2.Cube ");
                    ch = Convert.ToInt32(Console.ReadLine());
                    if (ch == 1)
                    {
                        Console.WriteLine(n.NumSquare);
                    }
                    else if (ch == 2)
                    {
                        Console.WriteLine(n.NumCube);
                    }

                    Console.WriteLine("Do you want to continue? Y/N: ");
                    con = Console.ReadLine();
                } while (con != "N" && con != "n");
            }
        }
    }