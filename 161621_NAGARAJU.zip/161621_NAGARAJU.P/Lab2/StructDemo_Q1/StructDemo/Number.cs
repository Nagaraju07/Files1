﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StructDemo
{
    class Number
    {
        int number;
        public Number(int number)
        {
            this.number = number;
        }

        public int NumSquare
        {
            get { return number * number; }
            set { number = value; }
        }

        public int NumCube
        {
            get { return number * number * number; }
            set { number = value; }
        }

    }
}