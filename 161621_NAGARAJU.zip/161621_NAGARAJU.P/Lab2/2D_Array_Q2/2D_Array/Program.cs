﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2D_Array
{
    class Program
    {
        static void Main(string[] args)
        {
           int[,] array = new int[5, 6];
                int i, j;

                for (i = 0; i < array.GetLength(0); i++)
                {
                    for (j = 0; j < array.GetLength(0); j++)
                    {
                        Console.WriteLine("Enter number :");
                    array[i, j] = Int32.Parse(Console.ReadLine());
                    }
                }

                for (i = 0; i < array.GetLength(0); i++)
                {
                    for (j = 0; j < array.GetLength(0); j++)
                    {
                        Console.Write("{0} ", array[i, j]);
                    }
                    Console.Write("\n" + Environment.NewLine + Environment.NewLine);
                }
                Console.ReadKey();

            }
        }
    }
